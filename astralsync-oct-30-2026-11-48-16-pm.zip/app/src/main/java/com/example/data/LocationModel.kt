package com.example.data

data class LocationCoordinate(
    val name: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String = "UTC"
)

object LocationPresets {
    // Primary default: Live Device Horizon as you travel
    val DEVICE_HORIZON = LocationCoordinate(
        name = "Local Horizon (Dynamic)",
        region = "Coordinates change as you travel",
        latitude = 40.7128,
        longitude = -74.0060,
        timeZoneId = "UTC"
    )

    // Beach Falls from the Test Run specifications
    val BEACH_FALLS = LocationCoordinate(
        name = "Beach Falls",
        region = "Test Run Horizon",
        latitude = 41.5000,
        longitude = -73.8500,
        timeZoneId = "America/New_York"
    )

    val ALBANY_NY = LocationCoordinate(
        name = "Albany Medical Center",
        region = "New York",
        latitude = 42.6532,
        longitude = -73.7745,
        timeZoneId = "America/New_York"
    )

    val GREENWICH_UK = LocationCoordinate(
        name = "Royal Observatory Greenwich",
        region = "Prime Meridian",
        latitude = 51.4769,
        longitude = 0.0005,
        timeZoneId = "Europe/London"
    )

    val TOKYO_JP = LocationCoordinate(
        name = "Tokyo",
        region = "Eastern Horizon",
        latitude = 35.6762,
        longitude = 139.6503,
        timeZoneId = "Asia/Tokyo"
    )

    val SYDNEY_AU = LocationCoordinate(
        name = "Sydney",
        region = "Southern Hemisphere",
        latitude = -33.8688,
        longitude = 151.2093,
        timeZoneId = "Australia/Sydney"
    )

    val ALL_PRESETS = listOf(
        DEVICE_HORIZON,
        BEACH_FALLS,
        GREENWICH_UK,
        TOKYO_JP,
        SYDNEY_AU
    )
}
